import * as React from "react";

export default function Home() {
	return (
		<div>
			<p>hi</p>
		</div>
	);
}
